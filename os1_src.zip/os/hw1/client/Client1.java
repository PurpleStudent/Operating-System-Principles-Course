package os.hw1.client;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client1 {


    public static void main(String[] args) {
        try {
            Socket socket = null;

            socket = new Socket("localhost", 16543);

            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message = "1|2|1|1|2 3";
            output.println(message);


            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();

            System.out.println(response);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
