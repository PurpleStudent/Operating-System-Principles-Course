package os.hw1.master;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

public class ClientThread extends Thread{

    final Object sync= new Object();


    static LinkedList<Process> subServers = new LinkedList<>();

    private final Socket socket;
    static LinkedList <Request> requestQueue = new LinkedList<>();        // sync
    static LinkedList <Request> runningRequests = new LinkedList<>();     // sync
    static int lastUserId;        //sync


    public ClientThread(Socket socket)  {
        this.socket = socket;
    }































    static void check_processes_status (int master_port){
        ProcessHandle processHandle = ProcessHandle.current();
        if ( !processHandle.isAlive() ){
            String main_server_log= "master"+" "+"stop"+" "+processHandle.pid()+" "+master_port;
            System.out.println(main_server_log);
        }


        for (int i = 0; i < subServers.size() ; i++) {
            if (i==0){          // cache
                if ( !subServers.get(0).isAlive() ){
                    String cache_log= "cache"+" "+"stop"+" "+subServers.get(0).pid()+" "+9000;
                    System.out.println(cache_log);
                }
            }
            else {              // sub server
                if ( !subServers.get(i).isAlive() ){
                    String sub_server_log= "worker"+" "+(i-1)+" "+"stop"+" "+subServers.get(i).pid()+" "+(9000+i);
                    System.out.println(sub_server_log);
                }
            }
        }
    }






    static void check_status (String [][] classNamesAndWeights , int upper_bound_weight){

        //sort(requestQueue);   -------->   insert in order

        Request request;
        try {
            request= requestQueue.getFirst();        //?!
        }
        catch ( NoSuchElementException exception){
            request= null;
        }




            if ( request!=null ) {


                if ( cacheHasResultOfProgram(request) ) {
                    // update program and program queue
                    updateRequestWithCacheInformation(request);
                }



                else {
                    boolean in_process = false;

                    for (int i = 1; i < subServers.size(); i++) {
                        in_process = isProgramRunningNowInThisProcess(i, request, classNamesAndWeights);
                    }

                    if (!in_process) {
                        int min_w = upper_bound_weight;
                        int process_index_min_w = 0;          //?!



                        for (int i = 1; i < subServers.size(); i++) {
                            int response = giveTotalWeightOfProgramsRunningNow(i, request, classNamesAndWeights);


                            if (response < min_w) {
                                min_w = response;
                                process_index_min_w = i;
                            }
                        }

                        if (min_w < upper_bound_weight) {
                            if (Integer.parseInt(classNamesAndWeights[request.programsQueue.getLast() - 1][1])
                                    +
                                    min_w
                                    >
                                    upper_bound_weight)
                            {
                                // هیچ کار
                            }
                            else {
                                // bedim run kone
                                runProgram(process_index_min_w, request, classNamesAndWeights);
                            }
                        }
                    }
                }
            }

    }









    static boolean cacheHasResultOfProgram( Request request ){
        try {
            boolean bool = true;
            Socket socket = new Socket( InetAddress.getLocalHost() , 9000);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{" + request.programsQueue.getLast() + "}" +
                            "{" + request.input + "}" +
                            "{-1}" +
                            "{Say the answer!}";
            output.println(message);


            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();

            if ( response.equals("There is no answer!") ) {
                bool = false;        //?!
            }
            return bool;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

















    static void updateRequestQueueWithCacheInformation(){
        for (int i = 0; i < requestQueue.size(); i++) {
            updateRequestWithCacheInformation( requestQueue.get(i) );
        }
    }




    static void updateRequestWithCacheInformation(Request request){
        try {
            Socket socket = new Socket( InetAddress.getLocalHost() , 9000);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{" + request.programsQueue.getLast() + "}" +
                            "{" + request.input + "}" +
                            "{-1}" +
                            "{Say the answer!}";
            output.println(message);


            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();

            if (!response.equals("There is no answer!")) {
                request.programsQueue.removeLast();                  //?!
                request.input = Integer.parseInt(response);          //?!


                if (request.programsQueue.isEmpty()){
                    sendFinalResultToUser( response , request );
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }























    static void runProgram( int process_index_min_w , Request request , String [][] classNamesAndWeights ){
        try {
            //Process process = find process with min w;
            Socket socket = new Socket( InetAddress.getLocalHost() , 9000 + process_index_min_w);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{" + request.programsQueue.getLast() + "}" +
                            "{" + request.input + "}" +
                            "{" + classNamesAndWeights[request.programsQueue.getLast() - 1][1] + "}" +
                            "{" + request.userId + "}" +
                            "{Run program!}";
            output.println(message);
            //--------------------------------------------------------------------------------------------------------------------------------
            //Scanner input = new Scanner(socket.getInputStream());     //?!
            //String response = input.nextLine();
            socket.close();
            runningRequests.add(request);
            requestQueue.remove(request);         //?!
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


































    static boolean isProgramRunningNowInThisProcess( int process_index , Request request , String [][] classNamesAndWeights ){
        try {
            boolean in_process = false;
            Socket socket = null;
            socket = new Socket( InetAddress.getLocalHost() , 9000 + process_index);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{" + request.programsQueue.getLast() + "}" +
                    "{" + request.input + "}" +
                    "{" + classNamesAndWeights[request.programsQueue.getLast() - 1][1] + "}" +
                    "{" + request.userId + "}" +
                    "{Is this program running with this input now?}";
            output.println(message);
            //---------------------------------------------------------------------------------------------------------------------------
            Scanner input = new Scanner(socket.getInputStream());        // آیا اینجا جواب بگیرم ؟!
            String response = input.nextLine();
            if (response.equals("yes")) {
                in_process = true;
            }
            if (response.equals("no")) {
                in_process = false;
            }
            socket.close();
            return in_process;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }















    static int giveTotalWeightOfProgramsRunningNow ( int process_index , Request request , String[][]classNamesAndWeights ){
        try {
            Socket socket = null;
            socket = new Socket( InetAddress.getLocalHost() , 9000 + process_index);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{" + request.programsQueue.getLast() + "}" +
                            "{" + request.input + "}" +
                            "{" + classNamesAndWeights[request.programsQueue.getLast() - 1][1] + "}" +
                            "{" + request.userId + "}" +
                            "{give me total weight of programs running now}";
            output.println(message);
            //----------------------------------------------------------------------------------------------------------------------------
            Scanner input = new Scanner(socket.getInputStream());
            String response = input.nextLine();
            socket.close();
            return Integer.parseInt(response);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return 1000000000;
    }

























    @Override
    public void run() {
        try{
        // first inputs
        Scanner input = new Scanner(socket.getInputStream());
        String userRequest_or_subServerResult = input.nextLine();


        if (userRequest_or_subServerResult.indexOf('{') != -1) {     // message is from sub server (result of program)
            //----------------------------------------------------------------------------------------------------------------------------
            String remaining = userRequest_or_subServerResult;
            LinkedList<String> informationList = new LinkedList<>();

            while (!remaining.equals("")) {
                String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                informationList.add(info);  // Synchronized
                if (remaining.indexOf('}') + 1 == remaining.length()) {
                    remaining = "";
                } else {
                    remaining = remaining.substring(remaining.indexOf('}') + 1);
                }
            }
            //***************************************
            String name_of_program = informationList.get(0);
            int program_input = Integer.parseInt(informationList.get(1));
            int result = Integer.parseInt(informationList.get(2));
            int user_id = Integer.parseInt(informationList.get(3));
            //-----------------------------------------------------------------------------------------------------------------------------


            // save sub server result to cache
            saveResultToCache(name_of_program, program_input, result);


            // update request & remove from running list & send to client OR add to request list again
            synchronized (sync) {
                for (int i = 0; i < runningRequests.size(); i++) {
                    Request runningRequest = runningRequests.get(i);
                    if (runningRequest.userId == user_id) {

                        runningRequest.programsQueue.removeLast();
                        runningRequest.input = result;

                        runningRequests.remove(runningRequest);

                        if (runningRequest.programsQueue.isEmpty()) {    // request is completely solved!
                            //remove from both of list;
                            //return result to client;
                            sendFinalResultToUser(String.valueOf(result), runningRequest);
                        } else {
                            addInOrder(runningRequest);
                        }

                        break;
                    }
                }

            }

        }
        //--------------------------------------------------------------------------------------------------------------------------------------------------
        else {                                                    // message is from client
            int input_of_programs = Integer.parseInt(userRequest_or_subServerResult.substring(userRequest_or_subServerResult.indexOf(" ") + 1));
            String programs = userRequest_or_subServerResult.substring(0, userRequest_or_subServerResult.indexOf(" "));


            LinkedList<Integer> programsQueue = new LinkedList<>();

            String remaining = programs;

            while (!remaining.equals("")) {
                int program;

                if (remaining.indexOf('|') == -1) {
                    program = Integer.parseInt(remaining);
                    programsQueue.add(program);
                    remaining = "";
                } else {
                    program = Integer.parseInt(remaining.substring(0, remaining.indexOf('|')));
                    programsQueue.add(program);  // Synchronized
                    remaining = remaining.substring(remaining.indexOf('|') + 1);
                }
            }



            int userId;
            synchronized (sync) {
                userId = lastUserId + 1;     //sync
            }




            Request request = new Request(input_of_programs, socket, userId);
            request.programsQueue.addAll(programsQueue);

            synchronized (sync) {
                addInOrder(request);
            }
        }
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------

        /*while (running){
            sleep();
            checkResponse;
        }*/

        } catch (IOException e) {
            e.printStackTrace();
        }
    }




























    static void sendFinalResultToUser(String result , Request request){
        try {
            requestQueue.remove(request);         //?!
            runningRequests.remove(request);     //?!

            PrintWriter output = new PrintWriter(request.socket.getOutputStream(), true);
            output.println(result);
            output.println('\n');
            request.socket.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }












    void saveResultToCache( String name_of_program, int program_input, int result ){
        try {
            Socket socket = new Socket( InetAddress.getLocalHost() , 9000);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{" + name_of_program + "}" +
                            "{" + program_input + "}" +
                            "{" + result + "}" +
                            "{Save!}";
            output.println(message);


            Scanner input = new Scanner(socket.getInputStream());
            String cacheResponse = input.nextLine();
            socket.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

















    void addInOrder(Request request){
        if (requestQueue.size() == 0){
            requestQueue.add(request);
        }
        else {

            if (request.time < requestQueue.getFirst().time) {
                requestQueue.addFirst(request);
            }
            else {
                if (requestQueue.getLast().time < request.time) {
                    requestQueue.addLast(request);
                } else {
                    for (int i = 0; i < requestQueue.size() - 1; i++) {

                        if (requestQueue.get(i).time < request.time && request.time < requestQueue.get(i + 1).time) {
                            requestQueue.add(i + 1, request);
                        }

                    }

                }
            }
        }
    }













}























class Request{
    int input;
    LinkedList<Integer> programsQueue;
    Socket socket;
    int userId;
    long time;

    public Request(int input, Socket socket, int userId) {
        this.input = input;
        this.programsQueue = new LinkedList<>();
        this.socket = socket;
        this.time = System.currentTimeMillis();
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "Request{" +
                "input=" + input +
                ", programsQueue=" + programsQueue +
                ", userId=" + userId +
                ", time=" + time +
                '}';
    }
}