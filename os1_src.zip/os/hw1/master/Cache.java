package os.hw1.master;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Scanner;

public class Cache {

    public static void main(String[] args) throws IOException {



        Scanner scanner = new Scanner(System.in);
        int port = scanner.nextInt();

        ServerSocket serverSocket= new ServerSocket(port);








        while (true) {
            //System.out.println("waiting for Main Server...");
            Socket socket = serverSocket.accept();  //Main Server
            //System.out.println("Main Server connected.");

            Thread thread= new MainServerCacheThread(socket);
            thread.start();

        }
        //socket.close();
    }

}
































class MainServerCacheThread extends Thread{
    final Object sync= new Object();

    private final Socket socket;
    static LinkedList<ExecutionResult> executionResults = new LinkedList<>();


    public MainServerCacheThread(Socket socket)  {
        this.socket = socket;
    }




    @Override
    public void run() {
        try {
            // first inputs
            Scanner input = new Scanner(socket.getInputStream());
            String information = input.nextLine();


            //-----------------------------------------------------------------------------------------------------------------------------------------------------------
            String remaining = information;
            LinkedList<String> informationList = new LinkedList<>();

            while (!remaining.equals("")) {
                String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                informationList.add(info);  // Synchronized
                if (remaining.indexOf('}') + 1 == remaining.length()) {
                    remaining = "";
                } else {
                    remaining = remaining.substring(remaining.indexOf('}') + 1);
                }
            }
            //***************************************
            String name_of_program = informationList.get(0);
            String program_input = informationList.get(1);
            String program_output = informationList.get(2);
            String special_message = informationList.get(3);



            // processing
            String message = inputProcessing (
                    name_of_program ,
                    Integer.parseInt(program_input) ,
                    Integer.parseInt(program_output) ,
                    special_message) ; //question
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------
            // second outputs
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            output.println(message);
        }

        catch (IOException e) {
            e.printStackTrace();
        }
    }














    private String inputProcessing ( String name_of_program , int program_input , int program_output , String special_message ) {
            String response = "";
            //*****************************************************
            if (special_message.equals("Say the answer!")) {
                ExecutionResult executionResult = findExecutionResult(name_of_program, program_input);

                if (executionResult == null){
                    response = "There is no answer!";
                }
                else {
                    response = String.valueOf(executionResult.output);
                }
            }


            if (special_message.equals("Save!")){

                synchronized (sync) {
                    if (findExecutionResult(name_of_program, program_input) == null) {
                        ExecutionResult executionResult = new ExecutionResult(Integer.parseInt(name_of_program), program_input, program_output);
                        executionResults.add(executionResult);
                    }
                }


                response = "It is saved.";
            }


            return response;
    }

















    ExecutionResult findExecutionResult ( String name_of_program , int program_input ){
        ExecutionResult myExecutionResult = null;
        synchronized (sync) {
            for (int i = 0; i < executionResults.size(); i++) {
                ExecutionResult executionResult = executionResults.get(i);

                if (executionResult.program_number == Integer.parseInt(name_of_program)) {
                    if (executionResult.input == program_input) {

                        myExecutionResult = executionResult;
                        break;
                    }
                }
            }
        }
        return myExecutionResult;
    }









}













class ExecutionResult {
    int program_number;
    int input;
    int output;

    public ExecutionResult(int program_number , int input , int output) {
        this.program_number = program_number;
        this.input = input;
        this.output = output;
    }
}
