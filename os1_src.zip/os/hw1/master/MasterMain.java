package os.hw1.master;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class MasterMain {

    public static void main(String[] args) throws IOException {

        Scanner scanner = new Scanner(System.in);

        int portMaster = Integer.parseInt(scanner.nextLine());
        int numberOfWorkers = Integer.parseInt(scanner.nextLine());
        int w = Integer.parseInt(scanner.nextLine());
        int numberOfCommonArgs = Integer.parseInt(scanner.nextLine());

        String [] commonArgs = new String[numberOfCommonArgs];

        for (int i = 0; i < numberOfCommonArgs ; i++) {
            commonArgs[i] = scanner.nextLine();
        }

        int numberOfPrograms = Integer.parseInt(scanner.nextLine());

        String [][] classNamesAndWeights = new String[numberOfPrograms][2];


        for (int i = 0; i < numberOfPrograms; i++) {
            String classNameAndWeight = scanner.nextLine();

            classNamesAndWeights[i][0] = classNameAndWeight.substring (0, classNameAndWeight.indexOf(' '));
            classNamesAndWeights[i][1] = classNameAndWeight.substring (classNameAndWeight.indexOf(' ')+1);
        }

        //---------------------------------------------------------------------------------------------------------------------------

        /*System.out.println(portMaster+"   "+numberOfWorkers+"   "+w);
        System.out.println(numberOfCommonArgs);
        for (int i = 0; i < numberOfCommonArgs; i++) {
            System.out.println(commonArgs[i]);
        }
        System.out.println(numberOfPrograms);
        for (int i = 0; i < numberOfPrograms; i++) {
            System.out.println(classNamesAndWeights[i][0]+"   "+classNamesAndWeights[i][1]);
        }*/


        ProcessHandle processHandle = ProcessHandle.current();
        long main_server_pid= processHandle.pid();
        String main_server_log=
                "master"+" "+
                "start"+" "+
                main_server_pid+" "+
                portMaster;
        System.out.println(main_server_log);

        //----------------------------------------------------------------------------------------------------------------------------



        createSubServers(
                numberOfWorkers,
                w,
                ClientThread.subServers,
                portMaster,
                numberOfCommonArgs,
                commonArgs,
                numberOfPrograms,
                classNamesAndWeights);
        ServerSocket serverSocket= new ServerSocket(portMaster);





        // method 1
        /*Timer timer =new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run()
            {
                System.out.println("timer");
                ClientThread.check_request_queue( classNamesAndWeights , w );
                //change your variable values as required in this function as this will be invoked every 5 minutes
            }
        };
        timer.schedule(task ,  10);*/




        // method 2
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    ClientThread.check_status( classNamesAndWeights, w);
                }
            }
        });
        thread1.start();




        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    // update request queue with cache information
                    ClientThread.updateRequestQueueWithCacheInformation();
                }
            }
        });
        thread2.start();



        Thread thread3 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    ClientThread.check_processes_status(portMaster);
                }
            }
        });
        thread3.start();


















        while (true) {

            //System.out.println("waiting for a client...");
            Socket socket = serverSocket.accept();  //client
            //System.out.println("client connected.");


            Thread clientThread= new ClientThread(socket);
            clientThread.start();
        }
        //socket.close();
    }




























    static void createSubServers(
            int numberOfSubServers,
            int w,
            LinkedList<Process> subServers,
            int portMaster,
            int numberOfCommonArgs,
            String [] commonArgs,
            int numberOfPrograms,
            String [][] classNamesAndWeights) {

        try {

            LinkedList<String> commands = new LinkedList<>();
            for (int i = 0; i < numberOfCommonArgs ; i++) {
                commands.add(commonArgs[i]);
            }
            commands.add ("os.hw1.master.Cache");
            Process cache = new ProcessBuilder(commands).start();
            PrintStream printStream = new PrintStream(cache.getOutputStream());
            printStream.println(9000);
            printStream.flush();
            String cache_log= "cache"+" "+"start"+" "+cache.pid()+" "+9000;
            System.out.println(cache_log);
            subServers.add(0, cache);





















            for (int i = 1; i < numberOfSubServers + 1; i++) {

                LinkedList<String> myCommands = new LinkedList<>();
                for (int j = 0; j < numberOfCommonArgs ; j++) {
                    myCommands.add(commonArgs[j]);
                }
                myCommands.add("os.hw1.subServer.SubServer");
                Process subServer = new ProcessBuilder(myCommands).start();
                //-------------------------------------------------------------------------------------------------------------------
                PrintStream print_stream = new PrintStream(subServer.getOutputStream());
                //------------------------------------------------------------------------------------------------------------------
                print_stream.println(9000 + i);          // sub server port
                print_stream.println(portMaster);        // main server port
                print_stream.println(numberOfCommonArgs);
                for (int j = 0; j < numberOfCommonArgs ; j++) {
                    print_stream.println(commonArgs[j]);
                }
                print_stream.println(numberOfPrograms);
                for (int j = 0; j < numberOfPrograms ; j++) {
                    print_stream.println ( classNamesAndWeights[j][0]+" "+classNamesAndWeights[j][1] );
                }
                //---------------------------------------------------------------------------------------------------------------------
                print_stream.flush();

                String sub_server_log= "worker"+" "+(i-1)+" "+"start"+" "+subServer.pid()+" "+(9000+i);
                System.out.println(sub_server_log);
                subServers.add(i, subServer);
            }




            //processBuilder.command("notepad.exe");

        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }



















    void createSubServer( String className, int port ){
        //input stream and output stream baraye yek process hamoon chizie ke dare to konsool miniviseh;
        LinkedList<String> command = new LinkedList<>();
        command.add("java");
        command.add("-cp");
        command.add("out/production/MainServer/");
        command.add(className);
        command.add(String.valueOf(port));

        try {
            System.out.println(command);
            ProcessBuilder builder = new ProcessBuilder(command);
            Process process = builder.start();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
