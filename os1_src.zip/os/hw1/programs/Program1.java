package os.hw1.programs;

//import os.hw1.Tester;

import os.hw1.Tester;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

public class Program1 {

    public static void main(String[] args) throws InterruptedException {

        Scanner scanner= new Scanner(System.in);
        int n = scanner.nextInt();


        Thread.sleep(Tester.WAIT_P1 - 50);


        System.out.println(2 + n);
    }
}
