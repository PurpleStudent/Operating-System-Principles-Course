package os.hw1.programs;

//import os.hw1.Tester;

import os.hw1.Tester;

import java.util.Scanner;

public class Program2 {


    public static void main(String[] args) throws InterruptedException {


        Scanner scanner= new Scanner(System.in);
        int n = scanner.nextInt();

        Thread.sleep(Tester.WAIT_P2 - 50);

        System.out.println(2 * n);
    }
}
