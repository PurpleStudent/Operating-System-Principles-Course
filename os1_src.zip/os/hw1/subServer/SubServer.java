package os.hw1.subServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Scanner;

public class SubServer {

    public static void main(String[] args) throws IOException {

        Scanner scanner = new Scanner(System.in);

        int subServerPort =  Integer.parseInt(scanner.nextLine());
        int mainServerPort =  Integer.parseInt(scanner.nextLine());

        int number_of_common_args =  Integer.parseInt(scanner.nextLine());
        String [] commonArgs = new String[number_of_common_args];
        for (int i = 0; i < number_of_common_args ; i++) {
            commonArgs[i] = scanner.nextLine();
        }



        int numberOfPrograms = Integer.parseInt(scanner.nextLine());
        String [][] classNamesAndWeights = new String[numberOfPrograms][2];
        for (int i = 0; i < numberOfPrograms; i++) {
            String classNameAndWeight = scanner.nextLine();

            classNamesAndWeights[i][0] = classNameAndWeight.substring (0, classNameAndWeight.indexOf(' '));
            classNamesAndWeights[i][1] = classNameAndWeight.substring (classNameAndWeight.indexOf(' ')+1);
        }





        MainServerThread.number_of_common_args= number_of_common_args;
        MainServerThread.commonArgs= new String[number_of_common_args];
        for (int i = 0; i < number_of_common_args ; i++) {
            MainServerThread.commonArgs[i] = commonArgs[i];
        }


        MainServerThread.numberOfPrograms= numberOfPrograms;
        MainServerThread.classNamesAndWeights= new String[numberOfPrograms][2];
        for (int i = 0; i < numberOfPrograms ; i++) {
            MainServerThread.classNamesAndWeights[i][0]= classNamesAndWeights[i][0];
            MainServerThread.classNamesAndWeights[i][1]= classNamesAndWeights[i][1];

        }









        ServerSocket serverSocket= new ServerSocket(subServerPort);


        while (true) {
            //System.out.println("waiting for Main Server...");
            Socket socket = serverSocket.accept();  //Main Server
            //System.out.println("Main Server connected.");

            Thread mainServerThread= new MainServerThread(socket , mainServerPort);
            mainServerThread.start();
        }
        //socket.close();
    }
}
