package os.hw1.subServer;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Scanner;

public class MainServerThread extends Thread{

    final Object sync= new Object();

    private final Socket socket;
    static int total_weight_of_programs_running_now;   //?!

    static LinkedList<Process> subprocesses = new LinkedList<>();
    static LinkedList<InputAndProgram> currentInputsAndPrograms = new LinkedList<>();

    int mainServerPort;





    static int number_of_common_args;
    static String [] commonArgs;


    static int numberOfPrograms;
    static String [][] classNamesAndWeights;





    public MainServerThread(Socket socket , int mainServerPort)  {
        this.socket = socket;
        this.mainServerPort = mainServerPort;
    }







    @Override
    public void run() {
        try {
            // first inputs
            Scanner input = new Scanner(socket.getInputStream());
            String information = input.nextLine();
            //-----------------------------------------------------------------------------------------------------------------------------------------------------------
            String remaining = information;
            LinkedList<String> informationList = new LinkedList<>();

            while (!remaining.equals("")) {
                String info = remaining.substring(remaining.indexOf('{') + 1, remaining.indexOf('}'));
                informationList.add(info);  // Synchronized
                if (remaining.indexOf('}') + 1 == remaining.length()) {
                    remaining = "";
                } else {
                    remaining = remaining.substring(remaining.indexOf('}') + 1);
                }
            }
            //***************************************
            String program_number = informationList.get(0);
            String program_input = informationList.get(1);
            String program_weight = informationList.get(2);
            String user_id = informationList.get(3);
            String special_message = informationList.get(4);







            if (special_message.equals("Run program!")){
                runProgram(
                        Integer.parseInt(program_weight),
                        Integer.parseInt(program_number),
                        Integer.parseInt(program_input),
                        Integer.parseInt(user_id));
            }
            else {
                // processing
                String message = inputProcessing(
                        program_number,
                        Integer.parseInt(program_input),
                        Integer.parseInt(program_weight),
                        special_message,
                        Integer.parseInt(user_id)); //question
                //----------------------------------------------------------------------------------------------------------------------------------------------------------------
                // second outputs
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                output.println(message);
            }


        }

        catch (IOException e) {
            e.printStackTrace();
        }
    }
































    private String inputProcessing (String name_of_program,
                                    int program_input,
                                    int program_weight,
                                    String special_message,
                                    int userId) {

            String response = "";
            //*****************************************************


            if (special_message.equals("give me total weight of programs running now")) {
                response = String.valueOf(total_weight_of_programs_running_now);
            }

            if (special_message.equals("Is this program running with this input now?")) {
                response = isThisProgramRunningNow( Integer.parseInt(name_of_program) , program_input );
            }

            return response;

    }


















    void runProgram(
            int program_weight ,
            int program_number ,
            int program_input ,
            int userId){

        try {
            synchronized (sync) {
                total_weight_of_programs_running_now = total_weight_of_programs_running_now + program_weight;
            }

            LinkedList<String> commands = new LinkedList<>();
            for (int i = 0; i < number_of_common_args; i++) {
                commands.add(commonArgs[i]);
            }
            commands.add(classNamesAndWeights[program_number-1][0]);

            Process process = new ProcessBuilder(commands).start();
            PrintStream printStream = new PrintStream(process.getOutputStream());
            printStream.println(program_input);
            printStream.flush();
            //add to process List;
            InputAndProgram inputAndProgram =
                    new InputAndProgram(program_input, program_number);
            synchronized (sync) {
                currentInputsAndPrograms.add(inputAndProgram);
            }


            //----------------------------------------------------------------------------------------------------------------------------
            Scanner scanner = new Scanner(process.getInputStream());
            String result = scanner.nextLine();
            scanner.close();

            sendResultToMainServer( program_number, program_input, Integer.parseInt(result), userId);

            //remove from process List;

            process.destroy();         //---->???;
            synchronized (sync) {
                currentInputsAndPrograms.remove(inputAndProgram);  //?!
                total_weight_of_programs_running_now = total_weight_of_programs_running_now - program_weight;
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

























    void sendResultToMainServer(int program_number , int program_input , int result , int userId){
        try {
            Socket socket = new Socket( InetAddress.getLocalHost() , mainServerPort);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            String message =
                    "{" + program_number + "}" +
                    "{" + program_input + "}" +
                    "{" + result + "}" +
                    "{" + userId + "}" ;
            output.println(message);


            socket.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }



































    String isThisProgramRunningNow( int name_of_program , int program_input ) {
        String response = "no";

        synchronized (sync) {
            for (int i = 0; i < currentInputsAndPrograms.size(); i++) {
                InputAndProgram input_and_program = currentInputsAndPrograms.get(i);

                if (input_and_program.program == name_of_program) {
                    if (input_and_program.input == program_input) {
                        response = "yes";
                        break;
                    }
                }
            }
        }
        return response;
    }



}


















class InputAndProgram {
    int input;
    int program;

    public InputAndProgram(int input, int program) {
        this.input = input;
        this.program = program;
    }
}
